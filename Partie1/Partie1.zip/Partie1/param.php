<!-- Définition des constantes de connexion. -->

<?php
	define('USER', 'admin');
	define('PASSWORD', 'L@uise19');
	define('DSN', 'mysql:host=localhost;dbname=colyseum;charset=utf8;');
?>