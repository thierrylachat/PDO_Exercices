<?php
/**
 * nom du serveur 
 * server name
 */
define('HOST', 'localhost');
/**
 * Nom de la base de donnée
 * name of databases 
 */
define('DB_NAME', 'pdo-tp2');
/**
 * Nom d'utilisateur
 * User name
 */
define('USER', 'admin');
/**
 * Mot de Passe 
 * Password
 */
define('PASSWORD', 'L@uise19');
/**
 * Erreur sql
 */
define('ERR',[PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);